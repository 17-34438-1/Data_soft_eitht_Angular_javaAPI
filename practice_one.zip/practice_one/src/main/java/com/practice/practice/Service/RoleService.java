package com.practice.practice.Service;
import com.practice.practice.Model.Role;


import com.practice.practice.Repository.RoleRepository;
import com.practice.practice.Model.Role;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;

@Service
public class RoleService {
    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private HttpServletRequest request;

    public List<Role> UserRoleList(){
        List<Role> roles = new ArrayList<Role>();
        String exception = null;
        try
        {
            roles = roleRepository.UserRoleList();
        }catch(Exception ex)
        {
            ex.printStackTrace();
            exception = ex.getMessage();
        }
        return roles;
    }

//    public ResponseEntity<Role> getUserRoleById(Long id){
//        Role role = roleRepository.getUserRoleById(id);
//        return new ResponseEntity<>(role, HttpStatus.OK);
//    }

}
