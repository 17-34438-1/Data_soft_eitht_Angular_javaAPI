package com.practice.practice.Repository;

import org.springframework.data.jpa.repository.Query;
import com.practice.practice.Model.Role;
import com.practice.practice.Service.RoleService;
import com.practice.practice.Repository.RoleRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface RoleRepository extends CrudRepository<Role, Long> {

    @Query(value = "SELECT * FROM test.user_role", nativeQuery = true)
    public List<Role> UserRoleList();

//    @Query(value = "SELECT * FROM test.user_role WHERE id=:id", nativeQuery = true)
//    public Role getUserRoleById(@Param("id") Long id);
}
