package com.practice.practice.Repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import com.practice.practice.Model.Role;
import com.practice.practice.Service.RoleService;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.transaction.Transactional;
import java.io.IOException;
import java.util.List;

public interface RoleRepository extends CrudRepository<Role, Long> {

    @Query(value = "SELECT * FROM test.user_role", nativeQuery = true)
    public List<Role> UserRoleList();

    @Query(value="SELECT * From test.user_role WHERE id=:id",nativeQuery = true)
    public Role getUserRoleById(@Param("id") Long id);


    @Query(value = "SELECT COUNT(*) FROM test.user_role WHERE role_name=:role_name", nativeQuery = true)
    Integer isExists(@Param("role_name") String role_name);



//
//    @Query(value = "SELECT * FROM test.user_role WHERE id=:id", nativeQuery = true)
//    public Role getUserRoleById(@Param("id") Long id);

//
//    Integer isExists(String role_name);

//
//    @Query(value = "SELECT COUNT(*) FROM test.user_role " +
//            "WHERE (role_name=:role_name) AND (id!=:id)", nativeQuery = true)
//    Integer isUnique(@Param("id") Long id,@Param("role_name") String role_name);
//
//
//    @Query(value = "SELECT COUNT(*) FROM test.user_role WHERE id=:id", nativeQuery = true)
//    Integer chkUserInfo(@Param("id") Long id);
//
//    @Query(value = "SELECT COUNT(*) FROM test.user_role WHERE id=:id", nativeQuery = true)
//    Integer chkUserAssignRole(@Param("id") Long id);

    @Modifying()
    @Query(value = "INSERT INTO test.user_role(role_name) " +
            "VALUES(:role_name)", nativeQuery = true)
    @Transactional
    Integer insertUserRole(@Param("role_name") String role_name);




//    @Modifying()
//    @Query(value="Update employee Set name=:name,dept=:dept,cat=:cat\n" +
//            "WHERE id=:id", nativeQuery = true )
//    @Transactional
//    public Integer  updateEmployee(@Param("id")Integer id, @Param("name") String name, @Param("dept") String dept, @Param("cat") String cat);
//

    @Query(value = "SELECT COUNT(*) FROM test.user_role " +
            "WHERE (role_name=:role_name) AND (id!=:id)", nativeQuery = true)
    Integer isUnique(@Param("id") Integer id, @Param("role_name") String role_name);



    @Modifying()
    @Query(value = "UPDATE user_role SET role_name=:role_name, " +
            " WHERE id=:id", nativeQuery = true)
    @Transactional
    public  Integer editUserRole(@Param("id") Integer id,
                         @Param("role_name") String role_name);


    //
//    @Query(value = "SELECT COUNT(*) From user_role WHERE id=:id",nativeQuery = true )
//    public Integer checkEmployeeExists(@Param("id") Integer id);
//
//
//    @Query(value = "SELECT COUNT(*) From employee WHERE id=:id",nativeQuery = true )
//    public Integer checkEmployeeExists(@Param("id") Integer id);



    @Modifying()
    @Query(value="DELETE From test.user_role where id=:id", nativeQuery = true )
    @Transactional
    public Integer  chkUserAssignRole(@Param("id") Integer id);



    @Modifying()
    @Query(value = "DELETE FROM test.user_role WHERE id=:id", nativeQuery = true)
    @Transactional
    Integer deleteUserRoleById(@Param("id") Integer id);



}
