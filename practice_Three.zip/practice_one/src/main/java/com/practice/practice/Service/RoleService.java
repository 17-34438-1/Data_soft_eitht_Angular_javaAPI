package com.practice.practice.Service;
import com.practice.practice.Model.ResponseMessage;
import com.practice.practice.Model.Role;


import com.practice.practice.Repository.RoleRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Service
public class RoleService {
    @Autowired
    private RoleRepository roleRepository;
    ResponseMessage responseMessage;
    @Autowired
    private HttpServletRequest request;

    public List<Role> UserRoleList(){
        List<Role> roles = new ArrayList<Role>();
        System.out.println("hi");
        String exception = null;
        try
        {
            roles = roleRepository.UserRoleList();
        }catch(Exception ex)
        {
            ex.printStackTrace();
            exception = ex.getMessage();
        }
        return roles;
    }

    public ResponseEntity<Role> getUserRoleById(Long id){
        Role role = roleRepository.getUserRoleById(id);
        return new ResponseEntity<>(role, HttpStatus.OK);
    }




    public ResponseEntity<ResponseMessage> add(Role role){
        String role_name = role.getRole_name();
        System.out.println("name="+role_name);
        Integer responseStatus = roleRepository.insertUserRole(role_name);
        if (responseStatus == 1){
            responseMessage = new ResponseMessage( "User Role Name Added Successfully");
            return new ResponseEntity(responseMessage, HttpStatus.CREATED);
        } else {
            responseMessage = new ResponseMessage( "Sorry! Could not add role name");
            return new ResponseEntity(responseMessage, HttpStatus.EXPECTATION_FAILED);
        }



    }






    public ResponseEntity<ResponseMessage> edit(@RequestBody Role role){
            Integer id = role.getId();
            String role_name = role.getRole_name();
            Integer response = roleRepository.editUserRole(id,role_name);
                if(response==1){
                    responseMessage = new ResponseMessage( "User Role Updated Successfully");
                    return new ResponseEntity(responseMessage, HttpStatus.OK);
                } else {
                    responseMessage = new ResponseMessage( "Sorry! Could not Update Data");
                    return new ResponseEntity(responseMessage, HttpStatus.EXPECTATION_FAILED);
                }
    }



    public  ResponseEntity<ResponseMessage>deleteUserRole( Integer id){
                Integer isExist= roleRepository.chkUserAssignRole(id);
                if(isExist == 1) {
                    responseMessage = new ResponseMessage( "User Role Deleted Successfully.");
                    return new ResponseEntity(responseMessage, HttpStatus.OK);
                } else {
                    responseMessage = new ResponseMessage( "Sorry! Could not delete data.");
                    return new ResponseEntity(responseMessage, HttpStatus.EXPECTATION_FAILED);
                }


    }



}
